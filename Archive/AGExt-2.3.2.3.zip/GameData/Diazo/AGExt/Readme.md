Action Groups Extended.

License: GPL3

Kerbal Space Program mod that increases the number of action groups to 250 and allows in-flight editing.